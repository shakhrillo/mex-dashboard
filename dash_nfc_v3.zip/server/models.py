from sqlalchemy import Boolean, Column, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from .database import Base

# class User(Base):
#     __tablename__ = "users"
#     id = Column(Integer,primary_key=True,index=True)
#     user_id = Column(String(255),index=True)
#     username = Column(String(255),index=True)
#     first_name = Column(String(255),index=True)
#     last_name = Column(String(255),index=True)
#     phone = Column(String(255),index=True)
#     user_info = relationship("Message", back_populates="user")
#     messages = relationship("Message", back_populates="user")



# class Message(Base):
#     __tablename__ = "messages"
#     id = Column(Integer, primary_key=True, index=True)
#     user_id = Column(Integer, ForeignKey("users.user_id"))
#     message = Column(String(255), index=True)
#     user = relationship("User", back_populates="user_info")
#     cities = Column(String(255), index=True)
#     date = Column(String(255), index=True)
#     types = Column(String(255), index=True)
#     car = Column(String(255), index=True)
#     phone = Column(String(255), index=True)

class Machine(Base):
    __tablename__ = "machines"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), index=True)
    status = Column(String(255), index=True)

class PartInfo(Base):
    __tablename__ = "partinfo"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), index=True)
    partName = Column(String(255), index=True)
    date = Column(String(255), index=True)
    time = Column(Float, index=True)
    type = Column(String(255), index=True)

class Main(Base):
    __tablename__ = "main"
    id = Column(Integer, primary_key=True, index=True)
    machineQrCode = Column(String(255), index=True)
    ToolMounted = Column(Boolean, index=True)
    MachineMounted = Column(Boolean, index=True)
    barcodeProductionNo = Column(String(255), index=True)
    partNumber = Column(String(255), index=True)
    partName = Column(String(255), index=True)
    cavity = Column(Integer, index=True)
    cycleTime = Column(Integer, index=True)
    partStatus = Column(String(255), index=True)
    pieceNumber = Column(Integer, index=True)
    note = Column(String(255), index=True)
    ToolCleaning = Column(String(255), index=True)
    remainingProductionTime = Column(Integer, index=True)
    OperatingHours = Column(Integer, index=True)
    